compiz-alike-windows-effect
==========================

Simplified "Compiz alike" wobbly windows effect.